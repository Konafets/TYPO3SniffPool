<?php
/**
 * Unit test class for TYPO3_Sniffs_Commenting_ClassDocCommentSniff.
 *
 * PHP version 5
 * TYPO3 version 4
 *
 * @category  Commenting
 * @package   TYPO3_PHPCS_Pool
 * @author    Andy Grunwald <andygrunwald@gmail.com>
 * @copyright 2010 Andy Grunwald
 * @license   http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @link      http://pear.typo3.org
 */
/**
 * Unit test class for TYPO3_Sniffs_Commenting_ClassDocCommentSniff.
 *
 * This unit test is copied and modified from PEAR_Tests_Commenting_ClassCommentUnitTest.
 * Thanks for this guys!
 *
 * @category  Commenting
 * @package   TYPO3_PHPCS_Pool
 * @author    Andy Grunwald <andygrunwald@gmail.com>
 * @copyright 2010 Andy Grunwald
 * @license   http://www.gnu.org/copyleft/gpl.html GNU Public License
 * @version   Release: 0.0.5
 * @link      http://pear.typo3.org
 */
class TYPO3SniffPool_Tests_Commenting_ClassDocCommentUnitTest extends AbstractSniffUnitTest
{
    /**
     * Returns the lines where errors should occur.
     *
     * The key of the array should represent the line number and the value
     * should represent the number of errors that should occur on that line.
     *
     * @return array(int => int)
     */
    public function getErrorList()
    {
        return array(
                2 => 1,
                10 => 1,
                14 => 1,
                17 => 1,
                20 => 1,
                35 => 1,
                46 => 1,
                53 => 1
                );
    }

    /**
     * Returns the lines where warnings should occur.
     *
     * The key of the array should represent the line number and the value
     * should represent the number of warnings that should occur on that line.
     *
     * @return array(int => int)
     */
    public function getWarningList()
    {
        return array();
    }
}
?>